<footer class="container-fluid footer_cont mt-5 mb-5">
      <div class="container">
        <div class="row">
        <div class="col-sm-6">
          <?php dynamic_sidebar('footerleft'); ?>
        </div>
        <div class="col-sm-6">
        <?php dynamic_sidebar('footerright'); ?>
        </div>
        </div>
      <div class="row container footer_bottom">
        <div class="col-sm-6">
        <?php dynamic_sidebar('footerbottomleft'); ?>
        </div>
        <div class="col-sm-6 text-end">
        <?php dynamic_sidebar('footerbottomright'); ?>
        </div>
      </div>
       </div>
    </footer>
    <!-- footer part end -->

<?php wp_footer();?>
</body>
</html>